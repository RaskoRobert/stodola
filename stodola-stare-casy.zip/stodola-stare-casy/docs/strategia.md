# Stodola Staré časy — Redizajn webu, štruktúra a obsahová stratégia

*Strategický podklad pre redizajn webu stodolastarecasy.sk + návrh obsahu pre sociálne siete a blog*

---

## 1. Zhrnutie a analýza súčasného stavu

Súčasný web plní základnú funkciu „vizitky", ale ako predajný a komunikačný nástroj zaostáva. Najväčší problém je, že **celá ponuka (menu, balíčky, priestory, ceny) je nahraná ako 21 obrázkov (JPG)** na jednej podstránke `/akcie/`.

### Hlavné problémy, ktoré treba vyriešiť

1. **Ponuka ako obrázky = neviditeľná pre Google.** Texty v obrázkoch Google nečíta. Keď niekto hľadá „svadba pri Košiciach", „sála na oslavu Trstené", „kar Košice okolie" — tento web sa neukáže, lebo tie slová nie sú v texte, len v JPG. To je strata desiatok potenciálnych dopytov mesačne.
2. **Zlá čitateľnosť na mobile.** Obrázok katalógu sa na telefóne musí približovať, text je drobný. Pritom väčšina návštevníkov príde z mobilu (Instagram/Facebook bio link).
3. **Žiadny rezervačný ani dopytový systém.** Jediná cesta ku kontaktu je telefón. Mladšia cieľovka (svadby, narodeniny) preferuje formulár / online dopyt, ideálne kedykoľvek (aj o 23:00).
4. **Prázdne blogové príspevky.** Články ako „Jedlo", „Výzdoba", „Halloween party 2023" obsahujú iba vložené video bez textu — pre SEO majú nulovú hodnotu.
5. **Nejednotné kontaktné údaje.** Web uvádza `0904 942 936`, katalóg `0903 625 815`. Treba zjednotiť (riziko straty dopytu).
6. **Chýba jasná cesta ku konverzii.** Návštevník nevie, aký je „ďalší krok" — kde zistí voľný termín, koľko to celé stojí, ako rezervovať.
7. **Technológia.** Slider Revolution + starší WordpPress build spomaľujú web a komplikujú údržbu.

### Čo naopak funguje a treba zachovať
- Silná vizuálna identita (jemný kvetinový/eukalyptový motív, logo so stodolou).
- Bohatý fotografický materiál z reálnych akcií (obrovská výhoda — autenticita).
- Príbeh „starých čias" + vidiecky/rustikálny priestor 20 km od Košíc.
- Aktívne sociálne siete (FB + IG).

---

## 2. Stratégia a cieľové skupiny

Podnik **nefunguje ako bežná reštaurácia, ale ako priestor na akcie.** Tomu musí byť podriadené celé UX: návštevník nepríde „pozrieť menu na obed", ale **plánuje udalosť** a hľadá, či sa jeho predstava dá u vás uskutočniť, kedy a za koľko.

### Cieľové skupiny (podľa hodnoty a podľa odlišných potrieb)

| Cieľovka | Čo hľadá ako prvé | Emócia | Rozhodovací čas |
|---|---|---|---|
| **Nevesty a ženíchy** (svadby) | Voľný termín, kapacita, atmosféra, slavobrána, balíčky výzdoby, fotky | Sen, dôvera, „bude to dokonalé" | dlhý (mesiace) |
| **Rodinné oslavy** (narodeniny, výročia, krstiny, promócie) | Kapacita salónika, menu, cena na osobu | Pohodlie, „postarajú sa o všetko" | stredný |
| **Smútočné posedenia (kar)** | Rýchle, dôstojné info, jednoduché menu, cena | Pokoj, citlivosť, rýchlosť | veľmi krátky (dni) |
| **Firmy** (firemné večierky, teambuildingy, školenia) | Kapacita, vybavenie (pódium, parkovanie), faktúra | Profesionalita, spoľahlivosť | stredný |
| **Detské oslavy** | Detské menu, ihrisko, animácie, maskoti | Bezpečie, zábava pre deti | krátky |
| **Komunitné / kultúrne akcie** (stavanie mája, Halloween, súťaž vo varení guláša) | Termíny verejných akcií, atmosféra | Zážitok, lokálnosť | krátky |

**Kľúčový UX princíp:** Hneď na úvodnej stránke nech si návštevník vyberie, „čo plánuje" — a web ho navedie presne na info relevantné preňho. Nikto nemá listovať 21 obrázkov, aby zistil, či máte slavobránu.

---

## 3. Navrhovaná štruktúra webu (sitemap)

```
DOMOV
│
├── PODUJATIA (rozcestník „Čo plánujete?")
│     ├── Svadby
│     ├── Rodinné oslavy (narodeniny, výročia, krstiny, promócie)
│     ├── Smútočné posedenia (kar)
│     ├── Firemné podujatia
│     ├── Detské oslavy
│     └── Kultúrne a spoločenské akcie
│
├── PRIESTORY
│     ├── Hlavná sála (kapacita ~80, pódium)
│     ├── Salónik (kapacita ~30)
│     └── Exteriér a okolie (dvor, altánky, terasa, detské ihrisko, lúka na obrad)
│
├── MENU & PONUKA
│     ├── Predjedlá
│     ├── Polievky
│     ├── Hlavné chody
│     ├── Detské menu
│     ├── Prílohy
│     ├── Studený bufet
│     ├── Teplý bufet
│     ├── Dezerty
│     ├── Menu na kar
│     └── Nápoje, open bar a prípitky
│
├── VÝZDOBA A BALÍČKY
│     ├── Základný balík (5 €/osoba)
│     ├── Deluxe balík (15 €/osoba)
│     ├── Svetelná zástena (95 €)
│     └── Slavobrána / svadobný obrad na lúke (250 €)
│
├── GALÉRIA (filtrovateľná: Svadby / Oslavy / Priestor / Jedlo / Akcie)
│
├── BLOG / MAGAZÍN  (SEO obsah — viď sekcia 8)
│
├── O NÁS (príbeh, prečo my, lokalita, tím)
│
├── REZERVÁCIA / NEZÁVÄZNÝ DOPYT  ⭐ (konverzný stred webu)
│
└── KONTAKT (mapa, otváracie hodiny, telefón, e-mail, formulár)
```

### Hlavné menu (navigácia) — odporúčaná podoba
`Domov · Podujatia · Priestory · Menu · Výzdoba · Galéria · Blog · Kontakt` + výrazné tlačidlo **„Overiť termín"** (sticky, vždy viditeľné, kontrastná farba).

> **Prečo „Overiť termín" a nie „Rezervovať":** pri eventoch sa nedá rezervovať na klik (treba ľudskú koordináciu menu, počtu hostí, personálu). „Overiť termín" je nižšia bariéra — človek len zistí dostupnosť, čím sa rozbehne komunikácia.

---

## 4. Detailný rozpis jednotlivých stránok

### 4.1 DOMOV
Cieľ: za 5 sekúnd je jasné, čo Stodola je, pre koho, a kam kliknúť.

Bloky zhora nadol:
1. **Hero video** (už ho máte — `Stodola-Stare-casy-1.mp4`) cez celú šírku, overlay s headline:
   *„Miesto, kde sa rodia spomienky"* / podtitul: *„Svadby, oslavy a firemné akcie 20 km od Košíc"* + 2 tlačidlá: **Overiť termín** · **Pozrieť priestory**.
2. **„Čo plánujete?"** — 6 dlaždíc (svadba, oslava, kar, firemná akcia, detská oslava, kultúrna akcia), každá s fotkou → vedie na príslušnú podstránku. *Toto je srdce nového UX.*
3. **Prečo Stodola** (3–4 ikony s krátkym textom): vlastná kuchyňa a čerstvé jedlo · kapacita do 80 + salónik 30 · kompletná výzdoba a personál · slavobrána a obrad priamo na lúke.
4. **Čísla/dôvera:** „X zorganizovaných svadieb", „X spokojných oslávencov", roky fungovania (ak chcete budovať dôveru).
5. **Ukážka priestoru** — 3–4 najlepšie fotky + odkaz do galérie.
6. **Recenzie / referencie** (Google recenzie, citácie nevest).
7. **Najbližšie verejné akcie** (stavanie mája, Halloween, súťaž guláš…) — ak sú aktuálne.
8. **Posledné články z blogu** (3 dlaždice).
9. **Veľký záverečný CTA blok:** „Máte termín v hlave? Overte si dostupnosť." + formulár alebo tlačidlo.
10. **Pätička:** kontakt, mapa, otváracie hodiny, sociálne siete, dôležité odkazy, GDPR.

### 4.2 PODUJATIA — vzor jednej podstránky (napr. SVADBY)
Každý typ akcie má vlastnú „pristávaciu" stránku podľa rovnakej šablóny, ale s vlastným tónom a obsahom:

1. **Emočný hero** (fotka svadobnej tabule / slavobrány pri západe slnka) + headline „Vaše áno v rustikálnej stodole pri Košiciach".
2. **Krátky úvod** — atmosféra, čo Stodola ponúka neveste/ženíchovi.
3. **Čo je v cene / čo zabezpečíme** — sála, výzdoba, kuchyňa, personál, obrad na lúke, pódium pre kapelu/DJ.
4. **Kapacita a priestory** — hlavná sála ~80 osôb + tanečný parket + pódium; salónik 30.
5. **Odporúčané menu pre svadbu** — výber 4–6 položiek z hlavných chodov + možnosť degustácie.
6. **Balíčky výzdoby** (Základný / Deluxe) + slavobrána + svetelná zástena, prehľadne s cenami.
7. **Galéria zo svadieb** (filter).
8. **Reálna referencia** (citát + fotka).
9. **FAQ** (časté otázky — výborné aj pre SEO, viď nižšie).
10. **CTA: „Overiť voľný termín na svadbu"**.

> Rovnaký skelet použijeme pre **Rodinné oslavy, Firemné podujatia, Detské oslavy, Kultúrne akcie**, pričom obsah a fotky prispôsobíme cieľovke.

**Špeciálny prípad — SMÚTOČNÉ POSEDENIA (KAR):** tu treba úplne iný, **tichý a vecný tón.** Žiadne veselé farby, žiadne „rezervujte zážitok". Stránka má dať rýchlo a dôstojne: jednoduché menu (guláš, rezeň), cenu, info že vieme zabezpečiť do pár dní, jednoduchú výzdobu (5 €/os.), telefón hneď na vrchu. Človek v smútku nemá listovať — musí to byť vyriešené 2 klikmi a telefonátom.

### 4.3 PRIESTORY
Samostatná stránka pre každý priestor, s veľa fotkami, kapacitou, cenou prenájmu a praktickými info (pódium, parkovanie, bezbariérovosť, klimatizácia, terasa):
- **Hlavná sála** — ~80 osôb, tanečný parket, vlastné pódium pre kapelu/DJ. Prenájom **300 €**.
- **Salónik** — ~30 osôb. Prenájom **80 €**.
- **Exteriér a okolie** — dvor s dvoma altánkami a hojdačkou, krytá vonkajšia terasa, detské ihrisko, lúka na svadobný obrad.

### 4.4 MENU & PONUKA
**Toto je najdôležitejšia SEO zmena.** Celé menu prepísať ako **text** (nie obrázky), rozdelené do kategórií s cenami. Každá položka = riadok s názvom, gramážou a cenou. Ideálne s možnosťou filtrovať (napr. „bezmäsité", „pre deti"). Detailný rozpis kategórií a položiek je v sekcii 7.

### 4.5 VÝZDOBA A BALÍČKY
Prehľadné porovnanie balíčkov (tabuľka Základný vs. Deluxe), čo obsahujú, foto príklady, doplnky (svetelná zástena 95 €, slavobrána 250 €). Veľmi vizuálna stránka — výzdoba „predáva" sama cez fotky.

### 4.6 GALÉRIA
Filtrovateľná podľa kategórií (Svadby / Rodinné oslavy / Priestor / Jedlo / Verejné akcie). Lightbox, rýchle načítanie (optimalizované fotky). Video sekcia.

### 4.7 REZERVÁCIA / DOPYT — viď samostatná sekcia 5.

### 4.8 O NÁS
Príbeh „starých čias", prečo stodola, kto za tým stojí, lokalita (20 km od Košíc, Trstené pri Hornáde), hodnoty (vlastná kuchyňa, čerstvé jedlo, rodinný prístup). Buduje dôveru — kľúčové pri svadbách.

### 4.9 KONTAKT
Mapa (Google), adresa JRD 77/A Trstené pri Hornáde, **zjednotené** telefónne číslo, e-mail, otváracie hodiny, formulár, odkazy na FB/IG.

---

## 5. Rezervačný / dopytový systém — workflow

Keďže ide o eventy (nie o stolovanie na klik), odporúčam **viackrokový nezáväzný dopytový formulár** napojený na **kalendár dostupnosti**.

### Tok (wizard, 4 kroky)
```
Krok 1 — TYP UDALOSTI
   [ Svadba ] [ Rodinná oslava ] [ Kar ] [ Firemná akcia ] [ Detská oslava ] [ Iné ]

Krok 2 — TERMÍN A POČET HOSTÍ
   Dátum (kalendár s vyznačenými obsadenými dňami) · Počet hostí (slider) ·
   Čas (od – do, s upozornením na príplatok 10 €/h po 23:00)

Krok 3 — PRIESTOR A BALÍČEK (predvyplnené podľa typu)
   Priestor: Hlavná sála / Salónik / Exteriér
   Výzdoba: Základný / Deluxe / bez výzdoby
   Doplnky: slavobrána, svetelná zástena, open bar, prípitok

Krok 4 — KONTAKT A POZNÁMKA
   Meno · Telefón · E-mail · Poznámka (alergie, špeciálne želania)
   [ Odoslať nezáväzný dopyt ]
```

### Po odoslaní
- Zákazník dostane **automatický e-mail**: „Ďakujeme, ozveme sa do 24 h" + zhrnutie dopytu.
- Prevádzka dostane **notifikáciu** (e-mail/SMS) s prehľadom.
- Dopyt sa zapíše do **interného kalendára** (Google Calendar / jednoduchý admin).

### Kalendár dostupnosti
Verejne viditeľný kalendár, kde sú **obsadené termíny** označené (bez detailov, len „obsadené"). Tým sa zníži počet zbytočných dopytov a zvýši dôvera. Pri svadbách je „je voľný 14.6.?" otázka č. 1.

> **Realistická poznámka:** Plne automatickú rezerváciu (platba kartou, okamžité potvrdenie) pri eventoch neodporúčam — každá akcia je iná a vyžaduje konzultáciu. Dopytový formulár + kalendár je správna miera medzi pohodlím a kontrolou prevádzky. Pri menších veciach (rezervácia stola na štvrtok–nedeľu) sa dá pridať jednoduchšia „rezervácia stola".

---

## 6. UX princípy (čo dodržať v celom dizajne)

1. **Mobile-first.** Väčšina príde z IG/FB na mobile. Všetko musí byť čitateľné a klikateľné palcom.
2. **Sticky tlačidlo „Overiť termín"** na každej stránke + telefón na jeden klik (`tel:` link).
3. **Rýchlosť.** Vymeniť Slider Revolution za ľahšie riešenie, komprimovať fotky (WebP). Cieľ < 2,5 s načítanie.
4. **Max. 3 kliky k cieľu.** Z domova → typ akcie → dopyt.
5. **Konzistentná vizualita** — jemný kvetinový/eukalyptový motív, ale striedmo (nech neprekrýva obsah, ako teraz v katalógu).
6. **Sociálny dôkaz všade** — recenzie, fotky reálnych akcií, počty.
7. **Prístupnosť** — dostatočný kontrast textu, alt texty fotiek (aj pre SEO).
8. **Dôvera a transparentnosť cien** — uvádzať ceny otvorene (máte ich, využite to; veľa konkurencie ceny tají, čo odrádza).

---

## 7. Menu — navrhovaná textová štruktúra (s dátami z katalógu)

> Toto prepíšte na webe ako **text**, nie obrázky. Nižšie je kompletný prepis z vášho katalógu pre rýchle nasadenie. Ceny si pred publikovaním overte/aktualizujte.

### Predjedlá
- 120 g Mäsová paštéta obalená v prerastenej slaninke, na omáčke z lesného ovocia s kvapkou brandy + banketové pečivo — **6,50 €**
- 120 g Paštéta z kačacích pečienok zaliata maslom, posyp z pistácií a lyofilizovaných malín + banketové pečivo — **6,50 €**
- 120 g Mozzarella s prosciuttom a paradajkou na ľahkom šaláte s bazalkovou redukciou + banketové pečivo — **5,50 €**
- 120 g Šunkovo-syrový tanier so zeleninovou oblohou + banketové pečivo — **5,50 €**

### Polievky
- 0,33 l Slepačia polievka s rezancami, mäsom a zeleninou — **3,30 €**
- 0,33 l Slepačia polievka s rezancami, mäsom, zeleninou a plnkou — **3,90 €**
- 0,33 l Hovädzí vývar s fliačkami, mäsom a zeleninou — **4,00 €**
- 0,33 l Hovädzí vývar s fliačkami, mäsom, zeleninou a plnkou — **4,50 €**
- 0,33 l Paradajkový krém so strúhaným parmezánom a čerstvou bazalkou — **4,00 €**
- 0,33 l Hráškový krém s glazovanou mrkvou — **3,50 €**
- 0,33 l Kapustnica s domácou klobásou, údeným mäsom a hubami — **4,90 €**

### Hlavné chody
- 250 g Kuracia galantína plnená žemľovo-slaninovou plnkou na zemiakovej kaši s cibuľkou, „redslav" šalát (z čerstvej červenej kapusty s majonézou) / možná výmena za miešaný alebo uhorkový — **16,50 €**
- 180 g Hovädzí stroganoff zo sviečkovice, ryža, hranolky, domáca tatárska omáčka — **18,50 €**
- 180 g Roláda z hovädzej sviečkovice plnená mozzarellou a sušenou paradajkou na mascarpone omáčke, ryža, americké zemiaky — **19,50 €**
- 180 g Medailóniky z bravčovej panenky v slaninovom župane na demi-glace omáčke, zemiaková štrúdľa s opraženou cibuľkou a pažítkou — **17,50 €**
- 200 g Filet zo pstruha s ratatouille zeleninou, zemiakové špízy s maslom a petržlenom — **17,50 €**
- 200 g Rolka z kačacieho stehna plnená gaštanovou plnkou, preliata výpekom, štrúdľa z červenej kapusty — **18,50 €**
- 180 g Kuracia rolka v prosciuttovom plášti plnená zelenou špargľou, cheddarová omáčka, cviklovo-zemiaková kaša — **17,50 €**
- 180 g Kačacie prsia s červenou kapustou a domácou lokšou — **19,50 €**
- 180 g Grilovaný kurací a bravčový plátok prekladaný zemiakovou plackou, coleslaw šalát, americké zemiaky — **17,50 €**
- 200 g Grilované filety z lososa s parenou zeleninou na masle — **15,50 €**
- 200 g Divinové ragú (jeleň, daniel), karlovarská knedľa — **15,50 €**
- 300 g Grilovaná zelenina s portobello šampiňónmi a opekanou kukuričnou polentou *(bezmäsité)* — **7,50 €**
- 350 g Sladké pirohy / ovocné knedle / šúľance plnené makom, s opraženým maslom a strúhankou *(bezmäsité)* — **7,50 €**
- 300 g Palacinky s džemom alebo vanilkovým pudingom, domáca čokoláda alebo teplá omáčka z lesného ovocia *(bezmäsité)* — **8,50 €**
- 1 kg Bravčové pečené stehno s kolienkom a kožou s prílohami (steril. zelenina, horčica, chlieb, čalamáda, chren; možnosť porciovania kuchárom) — **21 €/kg**
- 100 g MiniBurger / žemľa, hovädzie mäso, cheddar, listový šalát, slanina, kyslá uhorka, dressing podľa výberu — **9,50 €**

### Detské menu
- 100 g Vyprážaný kurací rezeň, hranolky a zeleninová obloha — **11 €**
- 100 g Kuracie mini steaky v demi-glace omáčke, ryža/hranolky a zeleninová obloha — **11 €**
- 100 g Kurací stroganoff s ryžou — **11 €**

### Špeciality a prílohy
- 150 g Domáca pečená jaternica s prílohami — **5,50 €**
- 150 g Domáca pečená klobása s prílohami — **6,50 €**
- 150 g Pečené bavorské koleno bez kosti s prílohami — **6,50 €**
- 180 g Bravčové líčka na čiernom pive s glazovanou zeleninou, zemiakovou štrúdľou a cibuľkou — **15,50 €**
- 200 g Prílohy (opekané zemiaky / varené zemiaky s maslom a petržlenom / dusená ryža / parená zelenina / grilovaná zelenina / americké zemiaky / steakové hranolky / hranolky) — **3 € / porcia**

### Studený bufet
- 1 kg Syrová roláda — **55 €/kg**
- 1 kg Mäsová roláda (bravčová, kuracia) — **65 €/kg**
- 1 kg Nárezová misa mix (šunka, saláma, dekor) — **65 €/kg**
- 1 kg Gazdovská misa (tlačenka, paprikový bôčik, oškvarky, suchá klobása, dekor) — **65 €/kg**
- 1 kg Filetované ovocie (grep, pomaranč, ananás, kiwi… podľa dostupnosti) — **35 €/kg**
- 250 g Zemiakový šalát s majonézou — **4,50 €**
- 250 g Miešaný zeleninový šalát — **3,50 €**
- 250 g Mrkvový šalát s ananásom — **2,50 €**
- 250 g Grécky zeleninový šalát s feta syrom a olivami — **4,00 €**
- 250 g Coleslaw šalát — **4,00 €**
- 250 g Rakúsky zemiakový šalát bez majonézy s tekvicovým olejom a cibuľkou + brusnicový dressing — **4,00 €**
- 200 g Zmes listových šalátov s cherry paradajkami a citrónovo-limetkovým dressingom — **3,50 €**

### Teplý bufet
- 350 g Bryndzové pirohy so slaninkou a kyslou smotanou — **8,50 €**
- 150 g Vyprážané kuracie mini rezne (2 ks) — **8,00 €**
- 150 g Vyprážané bravčové rezne (2 ks) — **8,00 €**
- 200 g Mix grilované stehienka — **5,50 €**
- 150 g Plnená kapusta z bravčového mäsa / holúbky (2 ks) — **8,50 €**
- 400 g Opekané zemiakové šúľance s dusenou kyslou kapustou, konfitovaná bravčová krkovička s výpekom — **10,50 €**
- 300 g Konfitované kačacie prsia s výpekom, kapustová štrúdľa z červenej kapusty a lístkového cesta — **19,50 €**
- 200 g Moravský bravčový vrabec, kysnutá knedľa, dusená kapusta (biela alebo červená) — **10,50 €**
- 200 g Maďarský guláš hovädzí (noky alebo domáca parená knedľa) — **14,50 €**

### Menu na kar
- 160 g/200 g Hovädzí maďarský guláš s knedľou — **15 €**
- 160 g/200 g Bravčový maďarský guláš s knedľou — **12 €**
- 160 g/200 g Kurací rezeň v cestíčku s varenými zemiakmi — **12 €**
- 160 g/200 g Kurací rezeň v cestíčku so zemiakovým šalátom — **15 €**
- Výzdoba na kar (stoly s obrusmi, servítky, svietniky, jemný kvetinový dekor) — **5 €/osoba**

### Nápoje, open bar a prípitky
- **Open bar** (nealko počas celej akcie): Mattoni, Pepsi, džbány s vodou a citrónom, čapované nealko (bazová limonáda alebo kofola) — **10 €/osoba**. Ku každému vybranému menu **1 káva na osobu grátis**. *(Vlastné nealko a pivo nie je povolené nosiť.)*
- **Prípitky:** 0,01 dcl Cinzano (pohár ozdobený cukrom) · 0,01 dcl Prosecco s jahodou · 0,04 dcl výber z destilátov — **2,00 €/ks**. Možnosť nealko prípitku.

### Dôležité poznámky (zobraziť pri menu)
- Pri každom hlavnom jedle ponúkame možnosť výmeny druhu mäsa, prílohy alebo šalátov podľa vášho výberu.
- Personál: po 23:00 sa účtuje príplatok **10 €/začatú hodinu na jedného čašníka** (počet personálu určuje prevádzka podľa počtu hostí).

---

## 8. Blog / Magazín — SEO stratégia

Cieľ blogu: **získať návštevníkov z Googlu**, ktorí hľadajú riešenie svojej akcie, a priviesť ich na dopytový formulár. Každý článok cieli na konkrétny vyhľadávací dopyt (kľúčové slovo) a má interný odkaz na príslušnú podstránku služby + CTA.

### Princípy
- 1 článok = 1 hlavná téma + 1 kľúčové slovo (napr. *„svadba pri Košiciach"*, *„kde spraviť kar Košice"*).
- Lokálne SEO: v textoch prirodzene spomínať **Košice, Trstené pri Hornáde, okolie Košíc, Abov**.
- Každý článok 800–1500 slov, vlastné fotky (nie stock), nadpisy H2/H3, FAQ na konci.
- Pridať **Google Business Profile** + zbierať recenzie (kľúčové pre lokálne SEO).

### Konkrétne témy článkov (návrhy + cieľové kľúčové slovo)

**Svadby**
1. *„Svadba v stodole pri Košiciach: kompletný sprievodca priestorom a cenami"* — kľúč: svadba pri Košiciach / svadobná sála Košice okolie
2. *„Vonkajší svadobný obrad na lúke: ako prebieha sobáš pod slavobránou"* — kľúč: svadobný obrad vonku / slavobrána
3. *„Koľko stojí svadba pre 80 hostí? Reálny rozpočet krok za krokom"* — kľúč: cena svadby / rozpočet svadby
4. *„Svadobné menu: ako vybrať jedlo, ktoré nadchne všetkých hostí"* — kľúč: svadobné menu
5. *„Rustikálna vs. elegantná svadobná výzdoba — porovnanie balíčkov"* — kľúč: svadobná výzdoba

**Oslavy a rodina**
6. *„Kde osláviť okrúhle narodeniny v okolí Košíc"* — kľúč: oslava narodenín Košice
7. *„Salónik pre rodinnú oslavu do 30 ľudí — čo všetko zariadime"* — kľúč: priestor na rodinnú oslavu
8. *„Krstiny a promócie: tipy na organizáciu menšej rodinnej akcie"*
9. *„Detská oslava, na ktorú deti nezabudnú: ihrisko, menu a animácie"* — kľúč: detská oslava Košice

**Kar (citlivý, ale vysoko vyhľadávaný)**
10. *„Smútočné posedenie (kar): ako ho dôstojne a bez stresu zabezpečiť"* — kľúč: kar Košice / smútočné posedenie. *(Tón pokojný, vecný, empatický.)*

**Firemné**
11. *„Vianočný firemný večierok pri Košiciach: priestor, menu, program"* — kľúč: firemný večierok Košice
12. *„Teambuilding mimo mesta: prečo funguje vidiecky priestor"*

**Sezónne / komunitné (aj na zdieľanie)**
13. *„Stavanie mája s dychovkou — naša obľúbená jarná tradícia"*
14. *„Halloween párty v Stodole: ako sme vyrezávali tekvice"*
15. *„Súťaž vo varení guláša — ako prebieha a ako sa prihlásiť"*

**Praktické / evergreen (priťahujú návštevnosť dlhodobo)**
16. *„7 vecí, ktoré si treba premyslieť pred rezerváciou priestoru na akciu"*
17. *„Ako naplánovať počet jedla a nápojov na 50 / 80 hostí"*
18. *„Trstené pri Hornáde: čo vidieť v okolí, keď k nám prídete"* — lokálny obsah

> **Tempo:** stačí 1–2 články mesačne. Dôležitejšia je pravidelnosť a kvalita než kvantita. Staršie sezónne články každý rok aktualizujte (zmeňte rok, doplňte nové fotky) — Google to odmení.

---

## 9. Sociálne siete — obsahová stratégia

Hlavná správa naprieč všetkým obsahom: **„Stodola je krásny priestor, kde si ľudia organizujú svoje najdôležitejšie akcie."** Predávame atmosféru a pocit „postarajú sa o nás".

### Mix formátov (odporúčaný pomer týždenne)
- 40 % — **reálne fotky/videá z akcií** (autenticita predáva najviac)
- 25 % — **carousel** (vzdelávací/ukážkový, „uloží si to")
- 20 % — **grafické príspevky** (ponuky, akcie, oznamy)
- 15 % — **reels/krátke videá** (dosah a noví ľudia)

### A) Carousel príspevky (viacobrázkové, „swipe")
Carousel je skvelý na ukladanie a zdieľanie. Námety:
1. **„5 dôvodov, prečo mať svadbu v stodole"** — 1 dôvod = 1 slide.
2. **„Pred a po: premena sály na svadobnú tabuľu"** — slidy ukazujúce transformáciu.
3. **„Základný vs. Deluxe balík výzdoby"** — porovnanie slide po slide.
4. **„Takto vyzerá menu na svadbu"** — predjedlo → polievka → hlavný chod → dezert.
5. **„3 typy priestoru u nás: sála, salónik, lúka"** — pre koľko ľudí sa hodí ktorý.
6. **„Ako prebieha obrad pod slavobránou"** — krok za krokom.
7. **„Detská oslava od A po Z"** — ihrisko, menu, maskoti.
8. **„Najčastejšie otázky neviest (a naše odpovede)"**.

### B) Grafické príspevky (dizajn v jednotnom štýle)
Pre oznamy, kde nie je potrebná fotka, alebo na zvýraznenie:
1. **Oznam o verejnej akcii** (stavanie mája, Halloween, súťaž guláš) — dátum, čas, výrazne.
2. **„Voľné termíny na rok 2026"** — ktoré mesiace/víkendy sú ešte voľné (vytvára urgenciu).
3. **Cenník balíčkov / „od koľko"** — transparentná grafika.
4. **Citát spokojného zákazníka** na peknom pozadí.
5. **Sezónna ponuka** (vianočné večierky, silvestrovské menu, jarné svadby).
6. **„Tip týždňa"** — krátka rada k plánovaniu akcie.

### C) Príspevky o akciách (verejné podujatia)
Vlastné podujatia = obsah, dosah aj nový zákazníci:
1. **Pozvánka pred akciou** (event na FB + príspevok + reel).
2. **Live/stories počas akcie** (atmosféra naživo).
3. **Zhrnutie po akcii** (fotky/video + poďakovanie + „tešíme sa na ďalší ročník").
4. **Throwback** na minulé ročníky (pripomenutie tradície).

### D) Bežné príspevky a videá z priestoru
Toto je vaša najsilnejšia zbraň — máte krásny priestor a reálny materiál:
1. **Video walkthrough** sály vyzdobenej na svadbu (pomalý záber).
2. **Detaily** — prestreté stoly, kvetinová výzdoba, svetelná zástena, slavobrána pri západe slnka (toto je „instagramovateľné").
3. **Jedlo** — close-up tanierov (predjedlá, hlavné chody, dezerty).
4. **Behind the scenes** — kuchyňa, príprava, tím (buduje dôveru a ľudskosť).
5. **Reels typu „transformácia"** — prázdna sála → vyzdobená (časozber).
6. **Sezónne** — stodola v jeseni, zasnežená v zime, kvitnúci dvor na jar.

### Praktické odporúčania
- **Konzistentná vizuálna identita** (rovnaké farby, font, logo na grafikách) — používajte jemný kvetinový motív z webu.
- **CTA v každom príspevku:** „Napíš nám do správ" / „Over si termín na webe" / link v bio.
- **Hashtagy:** mix lokálnych (#kosice #svadbakosice #stodolastarecasy) a tematických (#svadba2026 #rustikalnasvadba #oslava).
- **Stories/Highlights** rozdeliť podľa: Svadby · Oslavy · Priestor · Menu · Akcie · Recenzie.
- **Reagovať na správy rýchlo** — sociálne siete sú pre mladú cieľovku hlavný komunikačný kanál (preto je dôležitý aj formulár, ktorý dopyty zachytí mimo otváracích hodín).

---

## 10. Technické odporúčania

1. **Platforma:** ostať na WordPresse, ale prejsť na moderný, rýchly theme/builder (napr. čistý theme + blokový editor alebo ľahší builder) namiesto Slider Revolution. Ak je rozpočet, zvážiť aj prechod na rýchlejšie riešenie. Cieľ: rýchlosť a jednoduchá údržba (aby ste si menu/ceny vedeli meniť sami).
2. **Menu ako text, nie obrázky** — najvyššia priorita pre SEO.
3. **Optimalizácia fotiek** — WebP, lazy loading, komprimácia.
4. **Štruktúrované dáta (schema.org):** `LocalBusiness` / `Restaurant`, `Event`, `Menu`, `FAQPage` — pomáhajú Googlu zobraziť hviezdičky, otváracie hodiny, FAQ priamo vo výsledkoch.
5. **Google Business Profile** — založiť/optimalizovať, zbierať recenzie, pridať fotky. Pre lokálny biznis kľúčové.
6. **Rezervačný/dopytový formulár** s napojením na e-mail + kalendár (plugin alebo vlastné riešenie).
7. **Analytika** — Google Analytics 4 + Search Console, sledovať, odkiaľ chodia dopyty.
8. **Zjednotiť telefónne číslo** naprieč webom, katalógom aj sociálnymi sieťami.
9. **Sticky CTA + `tel:` a `mailto:` odkazy** na mobile.
10. **GDPR** — formulár so súhlasom, zachovať existujúce GDPR podstránky.

---

## 11. Odporúčané ďalšie kroky

1. **Schváliť štruktúru** (sitemap zo sekcie 3) — prípadné úpravy názvov/sekcií.
2. **Zjednotiť a doplniť údaje** — telefón, e-mail, kapacity, ceny (overiť aktuálnosť).
3. **Vyzbierať obsah** — texty o podniku, referencie/recenzie, roztriediť fotky do kategórií.
4. **Wireframe / dizajn** kľúčových stránok (Domov, Podujatia-vzor, Menu, Dopyt).
5. **Naplniť menu ako text** podľa sekcie 7.
6. **Spustiť blog** s 3–5 článkami na štart (svadby + kar + oslavy + 1 sezónny).
7. **Nastaviť obsahový plán na sociálne siete** (napr. mesačný kalendár podľa sekcie 9).
8. **Založiť/optimalizovať Google Business Profile** a spustiť zbieranie recenzií.

---

*Dokument slúži ako východiskový podklad. Každú sekciu vieme rozpracovať do detailu (wireframy, texty stránok, konkrétne znenia článkov, mesačný plán príspevkov).*
